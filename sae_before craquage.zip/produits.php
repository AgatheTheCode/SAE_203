<?php


     //traitement formulaire

var_dump($_POST);
$filtre = [];

if(isset($_POST['trier'])) 
{
  if(isset ($_POST['10'])){
    $filtre[0]= array ('name'=> $_POST['10'], 'value' => 1);
  }
  else{
    $filtre[0]= array ('value' => 0);
  }

  if(isset ($_POST['11'])){
    $filtre[1]= array ('name'=> $_POST['11'], 'value' => 1);
  }
  else{
    $filtre[1]= array ('value' => 0);
  }

  if(isset ($_POST['12'])){
    $filtre[2]= array ('name'=> $_POST['12'], 'value' => 1);
  }
  else{
    $filtre[2]= array ('value' => 0);
  }
  
  if(isset ($_POST['13'])){
    $filtre[2]= array ('name'=> $_POST['13'], 'value' => 1);
  }
  else{
    $filtre[2]= array ('value' => 0);
  }
  
  if(isset ($_POST['14'])){
    $filtre[2]= array ('name'=> $_POST['14'], 'value' => 1);
  }
  else{
    $filtre[2]= array ('value' => 0);
  }
  
  if(isset ($_POST['15'])){
    $filtre[2]= array ('name'=> $_POST['15'], 'value' => 1);
  }
  else{
    $filtre[2]= array ('value' => 0);
  }
  
  if(isset ($_POST['16'])){
    $filtre[2]= array ('name'=> $_POST['16'], 'value' => 1);
  }
  else{
    $filtre[2]= array ('value' => 0);
  }

}

//Include config file
include('include/twig.php');
$twig = init_twig();

include('include/config.php');
$pdo = connexion();
include('include/produits_data.php');
include_once('include/function.php');
$produit=filtre_traitement($pdo);



echo $twig->render('produits_template.twig', [
    'produit' =>$produit
]);
